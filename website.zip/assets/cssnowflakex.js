function uwu() {
  // https://embed.im/snow
var embedimSnow = document.getElementById("embedimx--snowx");

if (!embedimSnow) {
  function embRand(a, b) {
    return Math.floor(Math.random() * (b - a + 1)) + a;
  }

  var embCSS = '.embedimx-snowx{position: absolute;width: 30px;height: 30px;border-radius: 50%;margin-top:-10px}';
  var embHTML = '';

  for (i = 1; i < 60; i++) {
    embHTML += '<i class="embedimx-snowx"><img src="/src/assets/angpaooo.png"></img></i>';
    var rndX = embRand(0, 1000000) * 0.0001,
      rndO = embRand(-100000, 100000) * 0.0001,
      rndT = (embRand(3, 8) * 10).toFixed(2),
      rndS = (embRand(0, 10000) * 0.0001).toFixed(2);
    embCSS +=
      '.embedimx-snowx:nth-child(' +
      i +
      '){' +
      'opacity:' +
      (embRand(1, 10000) * 0.0001).toFixed(2) +
      ';' +
      'transform:translate(' +
      rndX.toFixed(2) +
      'vw,-10px) scale(' +
      rndS +
      ');' +
      'animation:fall-' +
      i +
      ' ' +
      embRand(10, 30) +
      's -' +
      embRand(0, 30) +
      's linear infinite' +
      '}' +
      '@keyframes fall-' +
      i +
      '{' +
      rndT +
      '%{' +
      'transform:translate(' +
      (rndX + rndO).toFixed(2) +
      'vw,' +
      rndT +
      'vh) scale(' +
      rndS +
      ')' +
      '}' +
      'to{' +
      'transform:translate(' +
      (rndX + rndO / 2).toFixed(2) +
      'vw, 105vh) scale(' +
      rndS +
      ')' +
      '}' +
      '}';
  }

  embedimSnow = document.createElement('div');
  embedimSnow.id = 'embedimx--snowx';
  embedimSnow.innerHTML =
    '<style>#embedimx--snowx{position:fixed;left:0;top:0;bottom:0;width:100vw;height:100vh;overflow:hidden;z-index:9999999;pointer-events:none}' +
    embCSS +
    '</style>' +
    embHTML;
  document.body.appendChild(embedimSnow);

  // Function to toggle the snow animation
  function toggleSnowAnimation() {
    var snowflakes = document.querySelectorAll('.embedimx-snowx');
    snowflakes.forEach((snowflake) => {
      snowflake.classList.toggle('animate-snow');
    });
  }

  // Call toggleSnowAnimation() when you want to toggle the animation (e.g., button click)
  // Example: <button onclick="toggleSnowAnimation()">Toggle Snow Animation</button>
}

}
uwu()